#Embedded file name: ACEStream\env.pyo
TS_ENV_PLATFORM = 'linux'
