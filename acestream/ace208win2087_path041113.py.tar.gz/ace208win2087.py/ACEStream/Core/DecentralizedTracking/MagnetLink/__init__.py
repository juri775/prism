#Embedded file name: ACEStream\Core\DecentralizedTracking\MagnetLink\__init__.pyo
EXTEND_MSG_METADATA = 'ut_metadata'
EXTEND_MSG_METADATA_ID = chr(224)
