#Embedded file name: ACEStream\Core\ProxyMode\__init__.pyo
pass
