#Embedded file name: ACEStream\Core\dispersy\__init__.pyo
pass
