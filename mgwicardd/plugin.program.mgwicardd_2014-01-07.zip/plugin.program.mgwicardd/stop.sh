#!/bin/sh

rm /var/lib/softcam/running
/etc/init.d/cardserver stop

exit 0

